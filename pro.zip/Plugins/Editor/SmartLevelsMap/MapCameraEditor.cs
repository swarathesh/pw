﻿using Assets.Plugins.SmartLevelsMap.Scripts;
using UnityEditor;
using UnityEngine;

namespace Assets.Plugins.Editor.SmartLevelsMap
{
	[CustomEditor(typeof(MapCamera))]
    public class MapCameraEditor : UnityEditor.Editor
    {
		public override void OnInspectorGUI()
		{
		}
    }
} 
