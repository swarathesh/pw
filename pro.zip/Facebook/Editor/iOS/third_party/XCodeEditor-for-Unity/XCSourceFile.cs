using UnityEngine;
using System.Collections;

namespace UnityEditor.XCodeEditor
{
	public class XCSourceFile : System.IDisposable
	{

		public void Dispose()
		{
			
		}
		
	}
}