using UnityEngine;
using System.Collections;

namespace UnityEditor.XCodeEditorChartboost
{
	public class XCSourceFile : System.IDisposable
	{

		public void Dispose()
		{
			
		}
		
	}
}