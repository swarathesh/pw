using UnityEngine;
using System.Collections;

namespace UnityEditor.XCodeEditorChartboost
{
	public class XCFileOperationQueue : System.IDisposable
	{

		public void Dispose()
		{
			
		}
		
	}
}